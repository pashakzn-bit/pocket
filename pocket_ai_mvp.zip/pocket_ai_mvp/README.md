# Pocket AI MVP

This is a small, mobile-friendly Progressive Web App starter. It runs in a browser and stores transactions and savings goals in that browser's local storage.

## Included
- Income and expense entry
- Transaction list and deletion
- Totals calculated from entered transactions
- Savings goal editor
- Rule-based budgeting coach (not a live AI service)
- Export data as JSON
- Basic PWA manifest and service worker

## Run locally
You can open `index.html` directly to try most features. For service-worker/offline-install behavior, serve the folder over HTTP:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Put it online for free
A simple path is GitHub Pages:
1. Create a GitHub account if you do not already have one.
2. Create a new public repository named `pocket-ai`.
3. Upload `index.html`, `manifest.webmanifest`, and `sw.js` to the repository root.
4. In repository Settings → Pages, choose deploy from the `main` branch and `/ (root)`.
5. Open the Pages URL GitHub gives you. It may take a few minutes to appear.

Do not put API keys, passwords, bank credentials, or secrets in these static files.

## Install on iPhone
After deploying to HTTPS, open the site in Safari → Share → Add to Home Screen. Browser labels can vary by iOS version.

## Before real users / launch
This is not yet a production financial app:
- No login, cloud sync, encrypted server-side storage, or account recovery
- No bank connection
- No live AI API integration
- No automated financial transactions
- Local browser data may be lost if site data is cleared; use Export my data for backups
- No security, privacy, accessibility, or financial compliance audit

Next development milestone: deploy a private test build, then add a backend with authentication and database rules before handling any sensitive user data. Keep a live AI integration behind a server endpoint; never expose a provider API key in browser code.
